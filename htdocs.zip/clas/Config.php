<?php 
class Config {
    const BASE_PATH = __DIR__;
}
?>