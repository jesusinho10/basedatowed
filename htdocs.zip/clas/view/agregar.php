
<form action="index.php?action=agregar" method="post">
  <input type="text" name="nombre" placeholder="Nombre" required>
  <textarea name="descripcion" placeholder="Descripción"></textarea>
  <input type="text" name="tipo" placeholder="Tipo" required>
  <input type="checkbox" name="activo" checked> Activo<br>
  <button type="submit">Agregar Tema</button>
</form>
